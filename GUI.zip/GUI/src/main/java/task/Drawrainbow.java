package task;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class Drawrainbow extends JPanel {

    private final static Color VIOLET = new Color(128, 0, 128);
    private final static Color INDIGO = new Color(75, 0, 130);

    private Color[] colors = {
        Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.BLUE,
        INDIGO, VIOLET
    };

    public Drawrainbow() {
        setBackground(Color.WHITE);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int radius = 20;
        int centerX = getWidth() / 2;
        int centerY = getHeight() - 10;

        for (int counter = 0; counter < colors.length; counter++) {
            g.setColor(colors[counter]);
            g.fillArc(centerX - (counter + 1) * radius, centerY - (counter + 1) * radius,
                    (counter + 1) * radius * 2, (counter + 1) * radius * 2, 0, -180);
        }
    }
}
