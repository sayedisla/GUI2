package task;

import javax.swing.JFrame;

public class DrawRainbowtest {

    public static void main(String[] args) {
        Drawrainbow panel = new Drawrainbow();
        JFrame application = new JFrame();

        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        application.add(panel);
        application.setSize(400, 250);
        application.setVisible(true);
    }
}
